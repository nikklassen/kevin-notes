#ifndef WIDGET_H
#define WIDGET_H

class Widget {
public:
    virtual void print() = 0;
};

#endif
